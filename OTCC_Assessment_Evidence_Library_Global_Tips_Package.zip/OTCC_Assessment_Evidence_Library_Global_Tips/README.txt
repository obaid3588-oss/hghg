OTCC Assessment Tool + Evidence Library
======================================

CONTENTS
--------
1. assessment.html
   The existing OTCC Assessment Tool with minimal integration changes only.

2. evidence-library.html
   The consolidated Evidence Library / Evidence Register.

3. CHANGELOG.txt
   Exact changes made to the original Assessment Tool.

4. VALIDATION.json
   Build and verification results.

HOW TO RUN OFFLINE
------------------
1. Keep assessment.html and evidence-library.html in the same folder.
2. Open assessment.html in Microsoft Edge or Google Chrome.
3. Click Evidence Library in the top header.
4. Click any OTCC control badge in the Evidence Library to return to that exact control in assessment.html.

CONTROL CATALOG
---------------
The Evidence Library does not contain a duplicate OTCC control database inside each evidence record. Each record stores only related control IDs. It obtains control statements, domains, subdomains, applicable levels, expected evidence and level classification from assessment.html through a read-only local page bridge.

If a browser or corporate policy blocks the local page bridge, click “Load Assessment File” in the Evidence Library and select assessment.html. The page then reads the same embedded control dataset directly from the selected file.

LEVEL COLOR LOGIC
-----------------
The Assessment Tool remains the source of truth. The Evidence Library receives each control’s existing levels array and effective level from assessment.html. No separate control-ID-to-level mapping is maintained in the Evidence Library.

- L1 badge: control applies only at L1.
- L2 badge: control applies at L1/L2 but not L3.
- L3 badge: control is part of the L3 baseline and therefore is also applicable to higher-criticality facilities.

LOCAL STORAGE
-------------
Assessment Tool key:
  otcc-full-assessment-v1-3-gotcc-domain1-1-4

Evidence Library key:
  otcc-evidence-library-v1

Evidence control-catalog cache key:
  otcc-evidence-control-catalog-cache-v1

The keys are separate. Evidence Library updates do not overwrite assessment responses.

INITIAL LIBRARY
---------------
- 30 consolidated evidence records (EV-001 through EV-030)
- 222 evidence-to-control associations
- Inline status and review updates
- Site Visit Mode
- Client-facing request list
- CSV exports and print view


GLOBAL OBAID TIPS
-----------------
Obaid Tips are stored separately from assessment responses under the browser key:
  otcc-obaid-tips-global-v1

A tip is added once to a control and is reused in every assessment opened with this
tool in the same browser storage context. Tips stack; adding a new tip appends it and
does not replace existing tips. Resetting responses or importing another assessment
does not delete or overwrite the global tips library.

Use Export Tips Pack to create a portable backup for another browser, device, or copy
of the tool. Browser localStorage can be cleared by browser/security policy, and local
file storage behavior can vary by browser, so the Tips Pack is the portability and
recovery mechanism.
